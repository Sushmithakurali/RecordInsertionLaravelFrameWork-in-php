<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class form extends Model
{
    //protected $fillable = ['id', 'name', 'class', 'division'];
}
