<!DOCTYPE html>
<html>
<head>
<title>SampleInsertion</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    
  <h2 >Sample Insertion</h2><br>
    
  <form class="form-horizontal" action="store" method="post" >
      {!! csrf_field() !!}
     
    <div class="form-group">
      <label class="control-label col-sm-2" >Student Id:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"  placeholder="Enter id" name="id" required>
      </div>
    </div><br>
       
    <div class="form-group">
      <label class="control-label col-sm-2"  >Student Name:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control"  placeholder="Enter name" name="name" required>
      </div>
    </div><br>
      
          <div class="form-group">
      <label class="control-label col-sm-2" >Student Class:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control"  placeholder="Enter class" name="class" required>
      </div>
    </div><br>
       
          <div class="form-group">
      <label class="control-label col-sm-2" >Student Division:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" placeholder="Enter division" name="division" required><br>
          
      </div>
    </div>

      
    
      
      <br>
      
   
      
        <button type="submit" class="btn btn-primary center-block" name="submit"  >ADD</button>
     
   
  </form>
</div>

                       

</body>
</html>
